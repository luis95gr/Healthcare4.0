package com.gnnetcom.jabrasdk.demo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.media.PlaybackParams;
import android.media.audiofx.PresetReverb;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.util.Log;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Example of a way to obtain two-way voice audio on a BT device.
 * <p>
 * As your requirements may require other functionality, this is just intended as an example, not recommended or endorsed by Jabra in any way.
 * <p>
 * Expect to spend some time experimenting :)
 */
@RequiresApi(api = Build.VERSION_CODES.M)
public class VoiceConnectorBT {
    private static final String TAG = "VoiceConnectorBT";
    private final Handler mCallbackHandler;
    private Handler mHandler;
    private Context mContext;
    private VoiceChannel mChannel = new VoiceChannel();
    private final AudioManager mAudioManager;


    public interface VoiceListener {
        void onData(short[] buffer);

        void onStarted();

        void onStopped();
    }

    VoiceConnectorBT(@NonNull Context c, Handler handler) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            throw new RuntimeException("Sorry - VoiceConnection requires Android M or newer"); //NOSONAR - keep SonarQube happy, it's ok to throw a generic exception here
        }
        mContext = c.getApplicationContext();
        HandlerThread h = new HandlerThread("vconn");
        h.start();
        mHandler = new Handler(h.getLooper());
        mCallbackHandler = handler;
        mAudioManager = (AudioManager) mContext.getSystemService(Context.AUDIO_SERVICE);
    }


    public void start() {
        Log.v(TAG, "opening voice audio...");

        mAudioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);  // despite the warnings in the comments for this, it is required. Otherwise, no audio is actually output (recorder works, but player not)
        mAudioManager.requestAudioFocus(null, AudioManager.STREAM_VOICE_CALL, AudioManager.AUDIOFOCUS_GAIN); // try, never mind the result...
        mContext.registerReceiver(mReceiver, new IntentFilter(AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED));
        mAudioManager.startBluetoothSco(); // startBluetoothScoVirtualCall is hidden ??
    }

    public void stop() {
        mChannel.stop();
        mAudioManager.setMode(AudioManager.MODE_NORMAL);
        mAudioManager.abandonAudioFocus(null);
    }

    public boolean isRecording() {
        return mChannel.mIsOpen.get();
    }

    public void play(final short[] buffer) {
        mChannel.play(buffer);
    }

    public void mute(boolean doMute) {
        mChannel.mute(doMute);
    }

    public void setListener(VoiceListener listener) {
        mChannel.setListener(listener);
    }

    // 2.5 produces a nice Mickey Mouse effect :)
    public void setPitch(float pitch) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            mChannel.setPitch(pitch);
        }
    }

    /**
     * @param reverb a PresetReverb.PRESET_* value
     */
    public void setReverb(short reverb) {
        mChannel.setReverb(reverb);
    }


    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED.equals(intent.getAction())) {
                int state = intent.getIntExtra(AudioManager.EXTRA_SCO_AUDIO_STATE, -1);
                if (AudioManager.SCO_AUDIO_STATE_CONNECTED == state) {
                    Log.d(TAG, "SCO connected");
                    mHandler.post(mChannel);
                }
                // the AudioManager.SCO_AUDIO_STATE_DISCONNECTED can apparently not be trusted, it may occur spuriously. We rely on the read loop below to catch spontaneous closing of the SCO.
            }
        }
    };

    private class VoiceChannel implements Runnable {
        private static final String TAG = "voicechannel";
        private static final int SAMPLERATE = 8000;
        private AudioTrack player;
        private AtomicBoolean mIsOpen = new AtomicBoolean(false);
        private AtomicBoolean mIsMuted = new AtomicBoolean(false);
        private VoiceListener mListener;

        @RequiresApi(api = Build.VERSION_CODES.M)
        @Override
        public void run() {
            doStart();
        }

        public void stop() {
            if (mIsOpen.getAndSet(false)) {
                Log.v(TAG, "Stopping");
            }
        }

        public void mute(boolean doMute) {
            Log.v(TAG, "Muted: " + doMute);
            mIsMuted.set(doMute);
        }

        @RequiresApi(api = Build.VERSION_CODES.M)
        private void doStart() {
            if (!mIsOpen.getAndSet(true)) {
                Log.v(TAG, "Starting");

                AudioRecord.Builder rb = null;
                rb = new AudioRecord.Builder();
                rb.setAudioFormat(new AudioFormat.Builder().setSampleRate(SAMPLERATE).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build());
                int rmbs = AudioRecord.getMinBufferSize(SAMPLERATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
                rb.setBufferSizeInBytes(2 * rmbs);
                rb.setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION);
                final AudioRecord recorder = rb.build();


                AudioTrack.Builder tb = new AudioTrack.Builder();
                tb.setAudioFormat(new AudioFormat.Builder().setSampleRate(SAMPLERATE).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build());
                int tmbs = AudioTrack.getMinBufferSize(SAMPLERATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
                tb.setBufferSizeInBytes(2 * tmbs);
                tb.setTransferMode(AudioTrack.MODE_STREAM);
                player = tb.build();

                recorder.startRecording();
                player.play();

                if (mListener != null) {
                    synchronized (mListener) {
                        mCallbackHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                mListener.onStarted();
                            }
                        });
                    }
                }

                short[] buffer = new short[rmbs];
                int n;
                // terminates if explicitly closed by stop(), or if read() fails
                while (mIsOpen.get() && (n = recorder.read(buffer, 0, buffer.length)) >= 0) {
                    if (n > 0 && mListener != null) {
                        synchronized (mListener) {
                            final short[] out = new short[n];
                            System.arraycopy(buffer, 0, out, 0, n);
                            mCallbackHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    if (!mIsMuted.get() && mListener != null) {
                                        mListener.onData(out);
                                    }
                                }
                            });
                        }
                    }
                }
                recorder.stop();
                recorder.release();

                player.flush();
                player.stop();
                player.release();

                try {
                    mContext.unregisterReceiver(mReceiver);
                } catch (IllegalArgumentException e) {
                    Log.v(TAG, "Failed to unregister bbcast receiver - not critical", e);
                }

                mAudioManager.stopBluetoothSco();
                Log.v(TAG, "stopped");

                if (mListener != null) {
                    synchronized (mListener) {
                        mCallbackHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                if (mListener != null) {
                                    mListener.onStopped();
                                }
                            }
                        });
                    }
                }
            }
        }


        @RequiresApi(api = Build.VERSION_CODES.M)
        void setPitch(float pitch) {
            if (mIsOpen.get()) {
                PlaybackParams pbp = new PlaybackParams().allowDefaults().setPitch(pitch);
                player.setPlaybackParams(pbp);
            }
        }


        // PresetReverb.PRESET_*
        void setReverb(short reverb) {
            if (mIsOpen.get()) {
                PresetReverb effect = new PresetReverb(0, player.getAudioSessionId());
                effect.setEnabled(true);
                effect.setPreset(reverb);
                player.attachAuxEffect(effect.getId());
            }
        }

        boolean addNoise = true; // just an example of data manipulation

        void play(short[] buffer) {
            if (mIsOpen.get() && !mIsMuted.get()) {
                if (addNoise) {
                    for (int n = 0; n < buffer.length; n++) {
                        buffer[n] += 100 * (Math.random() - 0.5f);
                    }
                }
                player.write(buffer, 0, buffer.length);
            }
        }

        public synchronized void setListener(VoiceListener listener) {
            mListener = listener;
        }
    }
}
