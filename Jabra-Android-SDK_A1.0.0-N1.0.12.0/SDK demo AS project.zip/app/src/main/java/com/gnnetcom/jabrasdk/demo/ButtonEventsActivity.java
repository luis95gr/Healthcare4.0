package com.gnnetcom.jabrasdk.demo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.widget.TextView;

import com.jabra.sdk.api.JabraDevice;
import com.jabra.sdk.api.JabraError;
import com.jabra.sdk.api.Listener;
import com.jabra.sdk.api.mmi.ButtonEvent;

import java.util.Arrays;

public class ButtonEventsActivity extends AppCompatActivity {

    private static final String TAG = ButtonEventsActivity.class.getSimpleName();

    private DeviceConnector mDeviceConnector;

    private TextView tvEvent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_button_events);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        mDeviceConnector = DeviceConnector.getInstance(this);

        tvEvent = (TextView) findViewById(R.id.event);
    }

    @Override
    protected void onStart() {
        super.onStart();
        mDeviceConnector.registerPresenter(mPresenter);

        JabraDevice device = mDeviceConnector.getConnectedDevice();
        if (device == null || !device.isConnected()) {
            finish();
        } else {
            subscribeToEvents(device);
        }
    }

    private void subscribeToEvents(JabraDevice device) {
        for (ButtonEvent buttonEvent : ButtonEvent.values()) {
            device.subscribeToButtonEvent(buttonEvent, mEventListener);
        }
    }

    private void unsubscribeToEvents(JabraDevice device) {
        for (ButtonEvent buttonEvent : ButtonEvent.values()) {
            device.unsubscribeFromButtonEvent(buttonEvent, mEventListener);
        }
    }


    @Override
    protected void onStop() {
        super.onStop();
        mDeviceConnector.unregisterPresenter(mPresenter);
        unsubscribeToEvents(mDeviceConnector.getConnectedDevice());
    }

    private Listener<ButtonEvent> mEventListener = new Listener<ButtonEvent>() {
        @Override
        public void onProvided(ButtonEvent value) {
            tvEvent.setText(value.name() + " (" + value.msgId + ")");
        }

        @Override
        public void onError(JabraError error, Bundle params) {
            if (error == JabraError.BUSY && params != null) {
                int uid = params.getInt(com.jabra.sdk.api.Callback.Keys.UID.name(), 0);
                String[] names = ButtonEventsActivity.this.getPackageManager().getPackagesForUid(uid);
                StringBuilder sb = new StringBuilder();
                sb.append("BUSY: Device buttons owned by ");
                sb.append(Arrays.toString(names));
                tvEvent.setText(sb.toString());
            } else {
                tvEvent.setText("Error " + error);
            }
        }
    };

    private DeviceConnector.Presenter2 mPresenter = new DeviceConnector.Presenter2() {
        @Override
        public void showMessage(String message, boolean loading) {
            Log.w(TAG, "showMessage() called with: message = [" + message + "], loading = [" + loading + "]");
        }

        @Override
        public void noDevice() {
            finish();
        }

        @Override
        public void updateConnectionStatus(boolean connected) {
            if (!connected) {
                finish();
            }
        }
    };

}
