package com.gnnetcom.jabrasdk.demo;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import com.jabra.sdk.api.Callback;
import com.jabra.sdk.api.DefaultCallback;
import com.jabra.sdk.api.DefaultListener;
import com.jabra.sdk.api.JabraDevice;
import com.jabra.sdk.api.JabraError;
import com.jabra.sdk.api.Listener;
import com.jabra.sdk.api.settings.JabraDeviceSetting;
import com.jabra.sdk.api.settings.JabraDeviceSettings;

public class SettingsActivity extends AppCompatActivity {

    private static final String TAG = SettingsActivity.class.getSimpleName();

    private JabraSettingsAdapter mAdapter;
    private DeviceConnector mDeviceConnector;
    private boolean canDoFactoryReset = false;
    private boolean mGetAllSettings = false;

    private Listener<Void> mSettingsChangeListener = new DefaultListener<Void>() {
        @Override
        public void onProvided(Void aVoid) {
            // somebody else changed a setting - update our view
            if (mAdapter != null && !SettingsActivity.this.isDestroyed() && !SettingsActivity.this.isFinishing()) {
                JabraDevice device = mDeviceConnector.getConnectedDevice();
                if (device != null && device.isConnected()) {
                    getSettings(device);
                }
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);


        mDeviceConnector = DeviceConnector.getInstance(this);

        mAdapter = new JabraSettingsAdapter(null);
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(mAdapter);
    }

    @Override
    protected void onStart() {
        super.onStart();
        mDeviceConnector.registerPresenter(mPresenter);

        JabraDevice device = mDeviceConnector.getConnectedDevice();
        if (device == null || !device.isConnected()) {
            finish();
        } else {
            getSettings(device);
            checkIfCanDoFactoryDefault(device);
            device.subscribeToSettingsChanges(mSettingsChangeListener);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        JabraDevice device = mDeviceConnector.getConnectedDevice();
        if (device != null) {
            device.unsubscribeFromSettingsChanges(mSettingsChangeListener);
        }
        mDeviceConnector.unregisterPresenter(mPresenter);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_settings, menu);

        MenuItem item = menu.findItem(R.id.showAll);
        Switch sw = (Switch) item.getActionView().findViewById(R.id.swWhichSettings);
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                mGetAllSettings = buttonView.isChecked();
                JabraDevice device = mDeviceConnector.getConnectedDevice();
                if (device != null && device.isConnected()) {
                    getSettings(device);
                }
            }
        });
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        menu.findItem(R.id.facdef).setIcon(canDoFactoryReset ? R.drawable.ic_action_facdef : R.drawable.ic_action_facdef_dis);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.facdef:
                if (canDoFactoryReset) {
                    setFactoryDefaults(mDeviceConnector.getConnectedDevice());
                } else {
                    new AlertDialog.Builder(SettingsActivity.this).setTitle("Not supported").setMessage("The device does not support factory reset").setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // No action
                        }
                    }).show();
                }
                return true;
            case R.id.swWhichSettings:
                if (item.getActionView() instanceof Switch) {
                    mGetAllSettings = ((Switch) item.getActionView()).isChecked();
                    JabraDevice device = mDeviceConnector.getConnectedDevice();
                    if (device != null && device.isConnected()) {
                        getSettings(device);
                    }
                }
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void getSettings(final JabraDevice device) {
        showLoading("Loading settings for " + device.getNameFromTransport(), true);
        device.getSettings(mGetAllSettings, new Callback<JabraDeviceSettings>() {
            @Override
            public void onProvided(JabraDeviceSettings value) {
                JabraDeviceSetting[] allSettings = value.getAllSettings();
                hideLoading();
                mAdapter.updateData(value.getAllSettings());
                if (allSettings.length == 0) {
                    mPresenter.showMessage("No settings found", false);
                }

                // IMPORTANT: When making local changes to the settings object (via the adapter),
                // forward this message to the connected device to apply
                value.setChangeListener(new JabraDeviceSetting.ChangeListener() {
                    @Override
                    public void onChanged(final JabraDeviceSetting s) {
                        device.setSetting(s, new Callback<Boolean>() {
                            @Override
                            public void onProvided(Boolean aBoolean) {
                                Log.v(TAG, "Setting " + s.getName() + (aBoolean ? "" : "NOT" + " updated "));
                            }

                            @Override
                            public void onError(JabraError jabraError, Bundle bundle) {
                                Log.e(TAG, "error updating settings: " + jabraError);
                            }
                        });
                    }
                });
            }

            @Override
            public void onError(JabraError error, Bundle params) {
                Log.e(TAG, "onError() called with: error = [" + error + "], params = [" + params + "]");
                mPresenter.showMessage("Settings fetch failed, " + error, false);
            }
        });
    }


    private void setFactoryDefaults(final JabraDevice device) {
        if (device != null) {
            new AlertDialog.Builder(this).setTitle("Set factory defaults?").setMessage("Reset to factory defaults? This may also disconnect the device").setNegativeButton("No", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    // no action
                }
            }).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    device.setFactoryDefaultSettings(new DefaultCallback<Boolean>());
                    getSettings(device); // refresh, in case device does not restart
                }
            }).setCancelable(false).show();
        }
    }

    private void checkIfCanDoFactoryDefault(JabraDevice device) {
        if (device != null) {
            device.checkSupportForFactoryDefaultsSettings(new Callback<Boolean>() {
                @Override
                public void onProvided(Boolean aBoolean) {
                    canDoFactoryReset = aBoolean;
                    invalidateOptionsMenu();
                }

                @Override
                public void onError(JabraError jabraError, Bundle bundle) {
                    canDoFactoryReset = jabraError == JabraError.NO_ERROR;
                    invalidateOptionsMenu();
                }
            });
        }
    }


    private DeviceConnector.Presenter2 mPresenter = new DeviceConnector.Presenter2() {
        @Override
        public void showMessage(String message, boolean loading) {
            SettingsActivity.this.showLoading(message, loading);
        }

        @Override
        public void noDevice() {
            finish();
        }

        @Override
        public void updateConnectionStatus(boolean connected) {
            if (!connected) {
                finish();
            }
        }
    };

    private void showLoading(String text, boolean loading) {
        findViewById(R.id.empty).setVisibility(View.VISIBLE);
        findViewById(R.id.progress_bar).setVisibility(loading ? View.VISIBLE : View.INVISIBLE);
        ((TextView) findViewById(R.id.progress_text)).setText(text);
    }

    private void hideLoading() {
        findViewById(R.id.empty).setVisibility(View.GONE);
        ((TextView) findViewById(R.id.progress_text)).setText(null);
    }
}
