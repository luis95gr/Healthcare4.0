package com.gnnetcom.jabrasdk.demo;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.SeekBar;
import android.widget.ToggleButton;

import com.jabra.sdk.api.DefaultCallback;
import com.jabra.sdk.api.DefaultListener;
import com.jabra.sdk.api.ICallControlHelper;
import com.jabra.sdk.api.JabraDevice;
import com.jabra.sdk.api.JabraError;

import java.util.Arrays;
import java.util.Set;

import static android.view.View.GONE;

public class CallControlActivity extends AppCompatActivity {

    private static final String TAG = CallControlActivity.class.getSimpleName();

    private DeviceConnector mDeviceConnector;

    private VoiceConnectorBT mVoiceConnector;
    private Handler mVoiceHandler;
    private TelephonyManager mTelephonyManager;
    private SeekBar mPitchControl;
    private Button btnRing;
    private Button btnInitiate;
    private Button btnAnswer;
    private Button btnReject;
    private Button btnHangup;
    private ToggleButton btnBusylight;

    private ICallControlHelper mCallControlHelper = null;
    private final VoiceConnectorBT.VoiceListener mVoiceListener = new MyVoiceListener();
    private final PhoneStateListener mPhoneStateListener = new MyPhoneStateListener();
    private Ringer mRinger;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call_control);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        mRinger = new Ringer(getApplicationContext(), "dblsweep.mp3");

        mDeviceConnector = DeviceConnector.getInstance(this);

        mVoiceHandler = new Handler();
        mTelephonyManager = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);

        mPitchControl = (SeekBar) findViewById(R.id.seekBar);
        mPitchControl.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (mVoiceConnector != null && mVoiceConnector.isRecording()) {
                    float pitch = rescale(progress, 0, seekBar.getMax(), .5f, 3f);
                    mVoiceConnector.setPitch(pitch);
                }
            }

            private float rescale(final float v, final float fromMin, final float fromMax, final float toMin, final float toMax) {
                float sv = Math.max(Math.min(v, fromMax), fromMin);
                return (sv - fromMin) / (fromMax - fromMin) * (toMax - toMin) + toMin;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // not used
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // not used
            }
        });

        btnRing = (Button) findViewById(R.id.btnRing);
        btnInitiate = (Button) findViewById(R.id.btnInitiate);
        btnAnswer = (Button) findViewById(R.id.btnAnswer);
        btnReject = (Button) findViewById(R.id.btnReject);
        btnHangup = (Button) findViewById(R.id.btnHangup);
        btnBusylight = (ToggleButton) findViewById(R.id.busylight);
        btnRing.setEnabled(false);
        btnInitiate.setEnabled(false);
        btnAnswer.setEnabled(false);
        btnReject.setEnabled(false);
        btnHangup.setEnabled(false);
        btnBusylight.setEnabled(false);

        btnInitiate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCallControlHelper != null) {
                    mCallControlHelper.onEvent(ICallControlHelper.CallEvent.INITIATE);
                }
            }
        });

        btnAnswer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCallControlHelper != null) {
                    mCallControlHelper.onEvent(ICallControlHelper.CallEvent.ACCEPT);
                }
            }
        });

        btnReject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCallControlHelper != null) {
                    mCallControlHelper.onEvent(ICallControlHelper.CallEvent.REJECT);
                }
            }
        });

        btnHangup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCallControlHelper != null) {
                    mCallControlHelper.onEvent(ICallControlHelper.CallEvent.HANGUP);
                }
            }
        });

        btnRing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCallControlHelper != null) {
                    mCallControlHelper.onEvent(ICallControlHelper.CallEvent.RING);
                }
            }
        });
        btnBusylight.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (mDeviceConnector.getConnectedDevice() != null) {
                    mDeviceConnector.getConnectedDevice().setBusylight(isChecked, new DefaultCallback<Void>() {
                        @Override
                        public void onError(JabraError jabraError, Bundle bundle) {
                            btnBusylight.setEnabled(jabraError == JabraError.NO_ERROR);
                        }
                    });
                }
            }
        });


        // note that some of the audio example code  depends on Android M
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            findViewById(R.id.incompatible).setVisibility(GONE);
            if (PackageManager.PERMISSION_GRANTED == ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)) {
                btnInitiate.setEnabled(true);
                btnRing.setEnabled(true);
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, 42);
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        mDeviceConnector.registerPresenter(mPresenter);
        mTelephonyManager.listen(mPhoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);

        JabraDevice device = mDeviceConnector.getConnectedDevice();
        if (device == null || !device.isConnected()) {
            finish();
        } else {
            activateVoiceListener(device);
            setupBusylight(device);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        mDeviceConnector.unregisterPresenter(mPresenter);
        mRinger.ring(false);

        deactivateVoiceListener(); // note that this implies hanging up if you UI goes away while in a call - for a real app, you probably don't want that...
        mTelephonyManager.listen(mPhoneStateListener, PhoneStateListener.LISTEN_NONE);
    }


    private void setupBusylight(JabraDevice device) {
        device.isBusylightSupported(new DefaultCallback<Boolean>() {
            @Override
            public void onProvided(Boolean aBoolean) {
                btnBusylight.setEnabled(aBoolean);
            }
        });
        device.isBusylightOn(new DefaultCallback<Boolean>() {
            @Override
            public void onProvided(Boolean aBoolean) {
                btnBusylight.setChecked(aBoolean);
            }
        });
    }

    private void activateVoiceListener(JabraDevice device) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            mVoiceConnector = new VoiceConnectorBT(this, mVoiceHandler);
            mVoiceConnector.setListener(mVoiceListener);
            mCallControlHelper = device.getCallControlHelper();
            if (mCallControlHelper != null) {

                mCallControlHelper.setActionListener(new DefaultListener<ICallControlHelper.CallAction>() {
                    @RequiresApi(api = Build.VERSION_CODES.M)
                    @Override
                    public void onProvided(ICallControlHelper.CallAction callAction) {
                        switch (callAction) {
                            case OPEN_AUDIO:
                                if (mVoiceConnector != null) {
                                    mVoiceConnector.start(); // direct initiation of audio link. mVoiceListener tells mCallControlHelper about state when established.
                                }
                                break;
                            case CLOSE_AUDIO:
                                if (mVoiceConnector != null) {
                                    mVoiceConnector.stop(); // direct teardown of audio link. mVoiceListener tells mCallControlHelper about state when closed
                                }
                                break;
                        }

                    }
                });

                mCallControlHelper.setStateListener(new DefaultListener<ICallControlHelper.CallState>() {
                    @Override
                    public void onProvided(ICallControlHelper.CallState callState) {
                        if (canAccessUi()) {
                            Snackbar.make(mPitchControl, callState.name(), Snackbar.LENGTH_SHORT).show();
                            Set<ICallControlHelper.CallEvent> events = mCallControlHelper.getEvents(callState);
                            btnInitiate.setEnabled(events.contains(ICallControlHelper.CallEvent.INITIATE));
                            btnRing.setEnabled(events.contains(ICallControlHelper.CallEvent.RING));
                            btnHangup.setEnabled(events.contains(ICallControlHelper.CallEvent.HANGUP));
                            btnAnswer.setEnabled(events.contains(ICallControlHelper.CallEvent.ACCEPT));
                            btnReject.setEnabled(events.contains(ICallControlHelper.CallEvent.REJECT));
                            mRinger.ring(callState == ICallControlHelper.CallState.INCOMING);
                        }
                    }
                });

                mCallControlHelper.setErrorListener(new DefaultListener<Void>() {
                    @Override
                    public void onError(JabraError jabraError, Bundle bundle) {
                        if (canAccessUi() && jabraError == JabraError.BUSY && bundle != null) {
                            int uid = bundle.getInt(com.jabra.sdk.api.Callback.Keys.UID.name(), 0);
                            String[] names = CallControlActivity.this.getPackageManager().getPackagesForUid(uid);
                            StringBuilder sb = new StringBuilder();
                            sb.append("Device buttons owned by ");
                            sb.append(Arrays.toString(names));
                            Snackbar.make(mPitchControl, sb.toString(), Snackbar.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        }
    }

    private boolean canAccessUi() {
        return mCallControlHelper != null && !CallControlActivity.this.isDestroyed() && !CallControlActivity.this.isFinishing();
    }

    private void deactivateVoiceListener() {
        if (mCallControlHelper != null) {
            mCallControlHelper.reset();
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (mVoiceConnector != null) {
                mVoiceConnector.stop();
                mVoiceConnector = null;
            }
            mCallControlHelper = null;
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        // ignored, voice button is enabled when a device is connected
    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    private class MyVoiceListener implements VoiceConnectorBT.VoiceListener{
        @Override
        public void onData(final short[] buffer) {
            // this is where you would connect to whatever you app requires (SIP/VOIP, ...)
            // Here, we just do something arbitrary to the audio stream... - like delay it by one second
            mVoiceHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (mVoiceConnector != null) {
                        mVoiceConnector.play(buffer);
                    }
                }
            }, 1000);
        }

        @Override
        public void onStarted() {
            // Hello, mr Mouse :)
            mVoiceConnector.setPitch(2f);
            if (mCallControlHelper != null) {
                mCallControlHelper.onEvent(ICallControlHelper.CallEvent.AUDIO_OPENED);
            }
        }

        @Override
        public void onStopped() {
            if (mCallControlHelper != null) {
                mCallControlHelper.onEvent(ICallControlHelper.CallEvent.AUDIO_CLOSED);
            }
        }
    }


    private class MyPhoneStateListener extends PhoneStateListener {
        @Override
        public void onCallStateChanged(int state, String incomingNumber) {
            switch (state) {
                case TelephonyManager.CALL_STATE_IDLE:
                    btnInitiate.setEnabled(mVoiceConnector != null && ActivityCompat.checkSelfPermission(CallControlActivity.this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED);
                    btnRing.setEnabled(true);
                    btnHangup.setEnabled(false);
                    btnAnswer.setEnabled(false);
                    btnReject.setEnabled(false);
                    break;
                case TelephonyManager.CALL_STATE_OFFHOOK:
                    btnInitiate.setEnabled(false);
                    btnRing.setEnabled(false);
                    btnHangup.setEnabled(false);
                    btnAnswer.setEnabled(false);
                    btnReject.setEnabled(false);
                    break;
                default:
                    break;
            }
        }
    }


    private DeviceConnector.Presenter2 mPresenter = new DeviceConnector.Presenter2() {
        @Override
        public void showMessage(String message, boolean loading) {
            Log.w(TAG, "showMessage() called with: message = [" + message + "], loading = [" + loading + "]");
        }

        @Override
        public void noDevice() {
            finish();
        }

        @Override
        public void updateConnectionStatus(boolean connected) {
            if (!connected) {
                finish();
            }
        }
    };

}
