package com.gnnetcom.jabrasdk.demo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.widget.TextView;

import com.jabra.sdk.api.JabraDevice;
import com.jabra.sdk.api.JabraError;
import com.jabra.sdk.api.Listener;
import com.jabra.sdk.api.sensor.SensorData;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class SensorDataActivity extends AppCompatActivity {

    private static final String TAG = SensorDataActivity.class.getSimpleName();

    private DeviceConnector mDeviceConnector;

    private TextView tvHr;
    private TextView tvStepRate;
    private TextView tvRri;
    private TextView tvStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_data);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        mDeviceConnector = DeviceConnector.getInstance(this);

        tvHr = (TextView) findViewById(R.id.hr);
        tvStepRate = (TextView) findViewById(R.id.steprate);
        tvRri = (TextView) findViewById(R.id.rri);
        tvStatus = (TextView) findViewById(R.id.status);
    }

    @Override
    protected void onStart() {
        super.onStart();
        mDeviceConnector.registerPresenter(mPresenter);

        JabraDevice device = mDeviceConnector.getConnectedDevice();
        if (device == null || !device.isConnected()) {
            finish();
        } else {
            subscribeToEvents(device);
        }
    }

    private void subscribeToEvents(JabraDevice device) {
        Set<SensorData.DataType> data = new HashSet<>();
        Collections.addAll(data, SensorData.DataType.values());
        device.subscribeToSensorData(data, mEventListener);
    }

    private void unsubscribeToEvents(JabraDevice device) {
        device.unsubscribeFromSensorData(mEventListener);
    }


    @Override
    protected void onStop() {
        super.onStop();
        mDeviceConnector.unregisterPresenter(mPresenter);
        unsubscribeToEvents(mDeviceConnector.getConnectedDevice());
    }

    private Listener<SensorData> mEventListener = new Listener<SensorData>() {
        @Override
        public void onProvided(SensorData value) {
            tvHr.setText(String.valueOf(value.getHeartRate()));
            tvStepRate.setText(String.valueOf(value.getStepRate()));
            tvRri.setText(value.getRRIdata().toString());
        }

        @Override
        public void onError(JabraError error, Bundle params) {
            String msg = error.name();
            if (error == JabraError.BUSY && params != null) {
                int uid = params.getInt(com.jabra.sdk.api.Callback.Keys.UID.name(), 0);
                String[] names = SensorDataActivity.this.getPackageManager().getPackagesForUid(uid);
                StringBuilder sb = new StringBuilder();
                sb.append("Device sensors owned by ");
                sb.append(Arrays.toString(names));
                sb.append(" - you may listen to whatever data is produced, but you cannot change the setup");
                msg += ": " + sb.toString();
            }

            Log.d(TAG, "onError() called with: error = [" + error + "], params = [" + params + "]   (" + msg + ")");
            tvHr.setText(null);
            tvStepRate.setText(null);
            tvRri.setText(null);
            tvStatus.setText(msg);
        }
    };

    private DeviceConnector.Presenter2 mPresenter = new DeviceConnector.Presenter2() {
        @Override
        public void showMessage(String message, boolean loading) {
            Log.w(TAG, "showMessage() called with: message = [" + message + "], loading = [" + loading + "]");
        }

        @Override
        public void noDevice() {
            finish();
        }

        @Override
        public void updateConnectionStatus(boolean connected) {
            if (!connected) {
                finish();
            }
        }
    };

}
