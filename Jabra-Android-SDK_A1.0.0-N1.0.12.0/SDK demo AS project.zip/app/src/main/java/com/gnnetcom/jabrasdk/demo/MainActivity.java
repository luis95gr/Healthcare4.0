package com.gnnetcom.jabrasdk.demo;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.jabra.jabrasdklibrary.*;
import com.jabra.sdk.api.DefaultListener;
import com.jabra.sdk.api.JabraDevice;
import com.jabra.sdk.api.JabraHelper;
import com.jabra.sdk.api.Listener;

public class MainActivity extends AppCompatActivity {

    private ViewGroup mButtonPanel;
    private DeviceConnector mDeviceConnector;
    private boolean mConnectedToJabra;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle(R.string.main_title);

        mButtonPanel = (ViewGroup) findViewById(R.id.buttonPanel);

        mDeviceConnector = DeviceConnector.getInstance(this);

        setupRefreshButton();

        ((TextView)findViewById(R.id.sdkversion)).setText("SDK: " + JabraHelper.getVersion());
        ((TextView)findViewById(R.id.appversion)).setText("APP: " + BuildConfig.BUILD_NO + (BuildConfig.GIT_COMMIT.isEmpty() ? "" : ("/" + BuildConfig.GIT_COMMIT.substring(0, 7))));
    }

    private void setupRefreshButton() {
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Long-press to reload", Snackbar.LENGTH_LONG).show();
            }
        });
        fab.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                mButtonPanel.setVisibility(View.GONE);
                mDeviceConnector.findConnectedDevice();
                return true;
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        mDeviceConnector.registerPresenter(mPresenter);
        mDeviceConnector.registerConnectionStateListener(mReceiver);

        JabraDevice device = mDeviceConnector.getConnectedDevice();
        if (device == null) {
            mDeviceConnector.findConnectedDevice();
        } else {
            if (device.isConnected()) {
                mPresenter.updateConnectionStatus(true);
            } else {
                mPresenter.updateConnectionStatus(false);
            }
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        mDeviceConnector.unregisterPresenter(mPresenter);
        mDeviceConnector.unregisterConnectionStateListener(mReceiver);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mDeviceConnector.unregisterConnectionStateListener(mReceiver);
        // note that this is not a good place to call mDeviceConnector.destroy() (or, put another way: do not tie the lifecycle of that singleton to the UI)
    }

    @Override
    public void onBackPressed() {
        // Be sure to close connection, when the application finished / closes down.
        // Alternatively, you could extend DeviceConnector to keep track of its clients, and start a short timer when the last client leaves. When the timer expires, self-destruct.
        mDeviceConnector.destroy();
        super.onBackPressed();
    }

    private DeviceConnector.Presenter2 mPresenter = new DeviceConnector.Presenter2() {
        @Override
        public void showMessage(String message, boolean loading) {
            MainActivity.this.showLoading(message, loading);
        }

        @Override
        public void noDevice() {
            mButtonPanel.setVisibility(View.GONE);
        }

        @Override
        public void updateConnectionStatus(boolean connected) {
            mConnectedToJabra = connected;
            if (connected) {
                hideLoading();
                mButtonPanel.setVisibility(View.VISIBLE);
                updateDeviceName();
            } else {
                mButtonPanel.setVisibility(View.GONE);
                MainActivity.this.showLoading("Connection lost  :(\n\nReconnect and wait for some seconds.", false);
            }
        }
    };

    private void updateDeviceName() {
        if (mDeviceConnector.getConnectedDevice() != null) {
            ((TextView) findViewById(R.id.name)).setText(mDeviceConnector.getConnectedDevice().getNameFromTransport());
        }
    }

    private Listener<Boolean> mReceiver = new DefaultListener<Boolean>() {
        @Override
        public void onProvided(Boolean connected) {
            if (connected && !mConnectedToJabra) {
                Snackbar.make(mButtonPanel, "Creating new connection", Snackbar.LENGTH_SHORT).show();
                mDeviceConnector.findConnectedDevice();
            }
        }
    };

    private void showLoading(String text, boolean loading) { //NOSONAR - ok to have this method at this level and not in the presenter, could be useful here, too
        findViewById(R.id.empty).setVisibility(View.VISIBLE);
        findViewById(R.id.progress_bar).setVisibility(loading ? View.VISIBLE : View.INVISIBLE);
        ((TextView) findViewById(R.id.progress_text)).setText(text);
    }

    private void hideLoading() { //NOSONAR - ok to have this method at this level and not in the presenter, could be useful here, too
        findViewById(R.id.empty).setVisibility(View.GONE);
        ((TextView) findViewById(R.id.progress_text)).setText(null);
    }

    public void openSettings(View view) { //NOSONAR - UI event response method
        startActivity(new Intent(this, SettingsActivity.class));
    }

    public void openCallControl(View view) {  //NOSONAR - UI event response method
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            startActivity(new Intent(this, CallControlActivity.class));
        }else{
            new AlertDialog.Builder(this).setTitle("Not available").setMessage("The call control demo is using Android audio API's present only on API23 (Marshmallow) or later").show();
        }
    }

    public void openButtonEvents(View view) { //NOSONAR - UI event response method
        startActivity(new Intent(this, ButtonEventsActivity.class));
    }

    public void openSensorData(View view) { //NOSONAR - UI event response method
        startActivity(new Intent(this, SensorDataActivity.class));
    }

    public void openDeviceInfo(View view) { //NOSONAR - UI event response method
        startActivity(new Intent(this, DeviceInfoActivity.class));
    }
}
