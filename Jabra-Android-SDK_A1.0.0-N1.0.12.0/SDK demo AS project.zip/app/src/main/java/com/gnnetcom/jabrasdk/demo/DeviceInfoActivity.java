package com.gnnetcom.jabrasdk.demo;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.jabra.sdk.api.Callback;
import com.jabra.sdk.api.JabraDevice;
import com.jabra.sdk.api.JabraError;
import com.jabra.sdk.api.Listener;
import com.jabra.sdk.api.assets.IJabraDeviceAssetManager;
import com.jabra.sdk.api.basic.BatteryStatus;

import java.io.File;
import java.io.IOException;

public class DeviceInfoActivity extends AppCompatActivity {

    private static final String TAG = DeviceInfoActivity.class.getSimpleName();

    private DeviceConnector mDeviceConnector;

    private TextView tvName;
    private TextView tvSerial;
    private TextView tvVersion;
    private TextView tvBattery;
    private ImageView ivImage;
    private TextView tvId;
    private TextView tvTransportName;
    private TextView tvConnection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_info);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        mDeviceConnector = DeviceConnector.getInstance(this);

        tvName = (TextView) findViewById(R.id.name);
        tvTransportName = (TextView) findViewById(R.id.transportName);
        tvId = (TextView) findViewById(R.id.id);
        tvConnection = (TextView) findViewById(R.id.connection);
        tvSerial = (TextView) findViewById(R.id.serial);
        tvVersion = (TextView) findViewById(R.id.version);
        tvBattery = (TextView) findViewById(R.id.battery);
        ivImage = (ImageView) findViewById(R.id.image);
    }

    @Override
    protected void onStart() {
        super.onStart();
        mDeviceConnector.registerPresenter(mPresenter);

        JabraDevice device = mDeviceConnector.getConnectedDevice();
        if (device == null || !device.isConnected()) {
            finish();
        } else {
            getDeviceInfo(device);
        }
    }


    @Override
    protected void onStop() {
        super.onStop();
        mDeviceConnector.unregisterPresenter(mPresenter);
    }

    private void getDeviceInfo(JabraDevice device) {
        // Synchronous calls
        tvTransportName.setText(device.getNameFromTransport());
        tvId.setText(device.getId());
        tvConnection.setText(device.getConnectionType().name());

        // Asynchronous calls
        device.getName(new Callback<String>() {
            @Override
            public void onProvided(String value) {
                tvName.setText(value);
            }

            @Override
            public void onError(JabraError error, Bundle params) {
                tvName.setText("??");
            }
        });
        device.getSerialNumber(new Callback<String>() {
            @Override
            public void onProvided(String value) {
                tvSerial.setText(value);
            }

            @Override
            public void onError(JabraError error, Bundle params) {
                tvSerial.setText("??");
            }
        });
        device.getVersion(new Callback<String>() {
            @Override
            public void onProvided(String value) {
                tvVersion.setText(value);
            }

            @Override
            public void onError(JabraError error, Bundle params) {
                tvVersion.setText("??");
            }
        });
        device.getBatteryStatus(1, new Listener<BatteryStatus>() {
            @Override
            public void onProvided(BatteryStatus value) {
                tvBattery.setText(value.getLevel() + "%" + (value.isCharging() ? " CHG " : "") + (value.isLow() ? " LOW " : ""));
            }

            @Override
            public void onError(JabraError error, Bundle params) {
                tvBattery.setText("??");
            }
        });
        showLoading("Loading image", true);
        device.getProductImageFile(IJabraDeviceAssetManager.PRODUCTIMAGE.FULL, new Callback<File>() {
            @Override
            public void onProvided(File value) {
                Bitmap bmp = null;
                if (value.exists()) {
                    try {
                        bmp = BitmapFactory.decodeFile(value.getCanonicalPath());
                    } catch (IOException e) {
                        Log.d(TAG, "Unable to retrieve product image", e);
                    }
                }
                if (bmp != null) {
                    ivImage.setImageBitmap(bmp);
                } else {
                    ivImage.setImageResource(R.drawable.placeholder);
                }
                hideLoading();
            }

            @Override
            public void onError(JabraError ignored, Bundle params) {
                hideLoading();
                ivImage.setImageResource(R.drawable.placeholder);
                Snackbar.make(ivImage, "Product image could not load [" + ignored + "]", Snackbar.LENGTH_SHORT).show();
            }
        });
    }

    private DeviceConnector.Presenter2 mPresenter = new DeviceConnector.Presenter2() {
        @Override
        public void showMessage(String message, boolean loading) {
            DeviceInfoActivity.this.showLoading(message, loading);
        }

        @Override
        public void noDevice() {
            finish();
        }

        @Override
        public void updateConnectionStatus(boolean connected) {
            if (!connected) {
                finish();
            }
        }
    };

    private void showLoading(String text, boolean loading) {
        findViewById(R.id.empty).setVisibility(View.VISIBLE);
        findViewById(R.id.progress_bar).setVisibility(loading ? View.VISIBLE : View.INVISIBLE);
        ((TextView) findViewById(R.id.progress_text)).setText(text);
    }

    private void hideLoading() {
        findViewById(R.id.empty).setVisibility(View.GONE);
        ((TextView) findViewById(R.id.progress_text)).setText(null);
    }
}
