package com.gnnetcom.jabrasdk.demo;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.util.Log;

import java.io.IOException;

public class Ringer {
    private static final String TAG = "Ringer";
    private MediaPlayer mPlayer;

    public Ringer(Context c, String assetName) {
        mPlayer = new MediaPlayer();
        try {
            AssetFileDescriptor ringTone = c.getAssets().openFd(assetName);
            mPlayer.setDataSource(ringTone.getFileDescriptor(), ringTone.getStartOffset(), ringTone.getLength());
            ringTone.close();
            mPlayer.prepare();
            mPlayer.setLooping(true);
        } catch (IOException e) {
            Log.w(TAG, "Unable to load ringtone asset", e);
        }
    }


    public void ring(boolean doRing) {
        Log.v(TAG, "Ring: " + doRing);

        mPlayer.stop();
        try {
            mPlayer.prepare();
        } catch (IOException e) {
            Log.d(TAG, "Failed to prepare player", e);
        }
        if (doRing) {
            mPlayer.start();
        }
    }
}
