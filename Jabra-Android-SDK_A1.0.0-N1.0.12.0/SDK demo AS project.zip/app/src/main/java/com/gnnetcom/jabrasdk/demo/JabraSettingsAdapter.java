package com.gnnetcom.jabrasdk.demo;

import android.app.AlertDialog;
import android.os.Handler;
import android.support.annotation.IdRes;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import com.jabra.sdk.api.settings.JabraDeviceSetting;
import com.jabra.sdk.api.settings.JabraDeviceSettingInfo;
import com.jabra.sdk.api.settings.JabraDeviceSettingList;
import com.jabra.sdk.api.settings.JabraDeviceSettingText;
import com.jabra.sdk.api.settings.JabraDeviceSettingToggle;
import com.jabra.sdk.api.settings.SettingKeyValuePair;

public class JabraSettingsAdapter extends RecyclerView.Adapter<JabraSettingsAdapter.ViewHolder> {

    private JabraDeviceSetting[] mDataset;
    private MyTextWatcher mMyTextWatcher = null;


    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public static class ViewHolder<T extends View> extends RecyclerView.ViewHolder { //NOSONAR - name is ok
        // each data item is just a string in this case
        final TextView name;
        final TextView help;
        final T value;
        final View restartInfo;  // optional!

        public ViewHolder(View v, @IdRes int res) {
            super(v);
            name = (TextView) v.findViewById(R.id.name);
            help = (TextView) v.findViewById(R.id.help);
            value = (T) v.findViewById(res);
            restartInfo = v.findViewById(R.id.infoCanRestartDevice);
            if (restartInfo != null) {
                restartInfo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        new AlertDialog.Builder(v.getContext()).setMessage(R.string.setting_restart_warning).show();
                    }
                });
            }
        }
    }

    // Provide a suitable constructor (depends on the kind of dataset)
    public JabraSettingsAdapter(JabraDeviceSetting[] myDataset) {
        mDataset = myDataset;
    }

    public void updateData(JabraDeviceSetting[] myDataset) {
        mDataset = myDataset;
        notifyDataSetChanged();
    }

    // Create new views (invoked by the layout manager)
    @Override
    public JabraSettingsAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // create a new view
        switch (viewType) {
            case 1:
                return new ViewHolder<Switch>(LayoutInflater.from(parent.getContext()).inflate(R.layout.settingitem_toggle, parent, false), R.id.toggle);
            case 2:
                return new ViewHolder<Spinner>(LayoutInflater.from(parent.getContext()).inflate(R.layout.settingitem_list, parent, false), R.id.options);
            case 3:
                return new ViewHolder<EditText>(LayoutInflater.from(parent.getContext()).inflate(R.layout.settingitem_text, parent, false), R.id.value);
            case 0:
            default: // error
                return new ViewHolder<TextView>(LayoutInflater.from(parent.getContext()).inflate(R.layout.settingitem_info, parent, false), R.id.value);
        }
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element
        JabraDeviceSetting s = mDataset[position];
        if (s instanceof JabraDeviceSettingInfo) {
            bindInfoItem(holder, (JabraDeviceSettingInfo) s);
        } else if (s instanceof JabraDeviceSettingToggle) {
            bindToggleItem(holder, (JabraDeviceSettingToggle) s);
        } else if (s instanceof JabraDeviceSettingList) {
            bindListItem(holder, (JabraDeviceSettingList) s);
        } else if (s instanceof JabraDeviceSettingText) {
            bindEditTextItem(holder, (JabraDeviceSettingText) s);
        } else {
            // error
            bindFallbackErrorItem(holder, s);
        }

        holder.itemView.setEnabled(s.isEnabled());
    }

    private void bindEditTextItem(ViewHolder<EditText> holderType, JabraDeviceSettingText t) {
        holderType.name.setText(t.getName());
        holderType.help.setText(t.getHelpText());
        holderType.value.setText(t.getValue());
        holderType.value.setEnabled(t.isEnabled());
        holderType.value.setOnFocusChangeListener(mFocusChangeListener); // we cannot just add a TextWatcher here, have to go via focus/defocus to avoid multiple textwatchers per view
        holderType.value.setTag(t); // bit of a hack, but we need to reference the setting from the focus listener...
    }

    private void bindListItem(ViewHolder<Spinner> holderType, JabraDeviceSettingList t) {
        holderType.name.setText(t.getName());
        holderType.help.setText(t.getHelpText());
        ArrayAdapter<String> adapter = new ArrayAdapter<>(holderType.itemView.getContext(), R.layout.simple_spinner_item, R.id.value);
        adapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
        for (SettingKeyValuePair keyValuePair : t.getOptions()) {
            adapter.add(keyValuePair.getValue());
        }
        holderType.value.setAdapter(adapter);
        holderType.value.setOnItemSelectedListener(null);
        holderType.value.setSelection(t.getCurrentSelectedIndex());
        holderType.value.setEnabled(t.isEnabled());
        holderType.value.setOnItemSelectedListener(new ListSelectionListener(this, t));
        if (holderType.restartInfo != null) {
            holderType.restartInfo.setVisibility(t.isChangeCausingDeviceRestart() ? View.VISIBLE : View.GONE);
        }
    }

    private void bindToggleItem(ViewHolder<Switch> holderType, JabraDeviceSettingToggle t) {
        holderType.name.setText(t.getName());
        holderType.help.setText(t.getHelpText());
        holderType.value.setTextOff(t.getOptions()[0].getValue()); // convention enforced by the Jabra Android SDK: index 0 is 'off' (key == 0)
        holderType.value.setTextOn(t.getOptions()[1].getValue());
        holderType.value.setOnCheckedChangeListener(null);
        holderType.value.setChecked(t.getCurrentSelectedIndex() != 0);
        holderType.value.setText(t.getOptions()[t.getCurrentSelectedIndex()].getValue());
        holderType.value.setOnCheckedChangeListener(new ToggleListener(this, t));
        holderType.value.setEnabled(t.isEnabled());
        if (holderType.restartInfo != null) {
            holderType.restartInfo.setVisibility(t.isChangeCausingDeviceRestart() ? View.VISIBLE : View.GONE);
        }
    }

    private void bindFallbackErrorItem(ViewHolder<TextView> holderType, JabraDeviceSetting s) {
        // error
        holderType.name.setText(s.getName());
        holderType.help.setText(s.getHelpText());
        holderType.value.setText("?? " + s.getClass().getName());
    }

    private void bindInfoItem(ViewHolder<TextView> holderType, JabraDeviceSettingInfo t) {
        holderType.name.setText(t.getName());
        holderType.help.setText(t.getHelpText());
        holderType.value.setText(t.getCurrentValue());
    }

    @Override
    public int getItemViewType(int position) {
        JabraDeviceSetting s = mDataset[position];
        if (s instanceof JabraDeviceSettingInfo) {
            return 0;
        } else if (s instanceof JabraDeviceSettingToggle) {
            return 1;
        } else if (s instanceof JabraDeviceSettingList) {
            return 2;
        } else if (s instanceof JabraDeviceSettingText) {
            return 3;
        } else {
            return 4;
        }
    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return mDataset != null ? mDataset.length : 0;
    }

    private View.OnFocusChangeListener mFocusChangeListener = new View.OnFocusChangeListener() {

        @Override
        public void onFocusChange(View v, boolean hasFocus) {
            Object o = v.getTag();
            if (v instanceof EditText && o instanceof JabraDeviceSettingText) {
                JabraDeviceSettingText s = (JabraDeviceSettingText) o;
                EditText e = (EditText) v;
                if (!hasFocus) {
                    if (mMyTextWatcher != null) {
                        mMyTextWatcher.commit(); // lost focus, update immediately
                        e.removeTextChangedListener(mMyTextWatcher);
                    }
                } else {
                    // set up for new EditText
                    mMyTextWatcher = new MyTextWatcher(new Handler(), s);
                    e.addTextChangedListener(mMyTextWatcher);
                }
            }
        }
    };

    private static class ToggleListener implements CompoundButton.OnCheckedChangeListener {
        private final JabraDeviceSettingToggle mSetting;
        private final RecyclerView.Adapter mAdapter;

        ToggleListener(RecyclerView.Adapter adapter, JabraDeviceSettingToggle setting) {
            mSetting = setting;
            mAdapter = adapter;
        }

        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            mSetting.toggleSelection();
            buttonView.setText(mSetting.getOptions()[mSetting.getCurrentSelectedIndex()].getValue());
            if (mSetting.hasDependentSettings()) {
                mAdapter.notifyDataSetChanged();
            }
        }
    }

    private static class MyTextWatcher implements TextWatcher {
        private final JabraDeviceSettingText mSetting;
        private final Handler mHandler;
        private String mCurrentValue = null;
        private Updater mUpdater = new Updater();


        MyTextWatcher(Handler handler, JabraDeviceSettingText setting) {
            mSetting = setting;
            mHandler = handler;
            mCurrentValue = mSetting.getValue();
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            // no action
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            // no action
        }

        @Override
        public void afterTextChanged(Editable s) {
            String v = s.toString();
            if(mSetting.canSetValueTo(v)) {
                if (!v.equals(mCurrentValue)) {
                    mCurrentValue = v;
                    mUpdater.setDirty();
                    mHandler.removeCallbacks(mUpdater);
                    mHandler.postDelayed(mUpdater, 2000); // reduce stress of device, max one update every 2 s
                }
            }else if(mCurrentValue != null){
                s.replace(0, s.length(), mCurrentValue);
            }else{
                s.clear();
            }
        }

        void commit() {
            mHandler.removeCallbacks(mUpdater);
            mUpdater.run();
        }

        private class Updater implements Runnable {

            private boolean isDirty = false;

            void setDirty() {
                isDirty = true;
            }

            @Override
            public void run() {
                if (mCurrentValue != null && isDirty) {
                    mSetting.setValue(mCurrentValue);
                    isDirty = false;
                }
            }
        }
    }


    private static class ListSelectionListener implements AdapterView.OnItemSelectedListener {
        private final JabraDeviceSettingList mSetting;
        private final RecyclerView.Adapter mAdapter;

        public ListSelectionListener(RecyclerView.Adapter adapter, JabraDeviceSettingList setting) {
            mSetting = setting;
            mAdapter = adapter;
        }

        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            int current = mSetting.getCurrentSelectedIndex();
            if (position != current) {
                mSetting.setCurrentSelectedIndex(position);
                if (mSetting.hasDependentSettings()) {
                    mAdapter.notifyDataSetChanged();
                }
            }
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {
            // no action
        }
    }
}
